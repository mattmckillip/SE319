package assembly;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.BevelBorder;
import javax.swing.table.DefaultTableModel;

public class AssemblyGUIv2 {

	private JFrame frmAntlrAssemblyHelper;
	private JTable outputTable;
	private JTable registerTable;
	private String g4FileName = System.getProperty("user.dir") + "\\ANTLR Code\\Assembly.g4";
	private String g4InputFileName = System.getProperty("user.dir") + "\\ANTLR Code\\Assembly.txt";
	private DefaultTableModel Statementmodel;
	private DefaultTableModel Registermodel;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AssemblyGUIv2 window = new AssemblyGUIv2();
					window.frmAntlrAssemblyHelper.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AssemblyGUIv2() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmAntlrAssemblyHelper = new JFrame();
		frmAntlrAssemblyHelper.setTitle("ANTLR Assembly Helper - Group 20");
		frmAntlrAssemblyHelper.setBounds(100, 100, 745, 612);
		frmAntlrAssemblyHelper.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmAntlrAssemblyHelper.getContentPane().setLayout(null);
		
	    JMenuBar menubar = new JMenuBar();
	    JMenu file = new JMenu("File");
	    file.setMnemonic(KeyEvent.VK_F);

	    JMenuItem eMenuItem = new JMenuItem("Exit");
	    eMenuItem.setMnemonic(KeyEvent.VK_E);
	    eMenuItem.setToolTipText("Exit application");
	    eMenuItem.addActionListener(new ActionListener() {
	    @Override
	    	public void actionPerformed(ActionEvent event) {
	            System.exit(0);
	        }
	    });

	    file.add(eMenuItem);
	    menubar.add(file);
	    
	    JMenu run = new JMenu("Run");
	    file.setMnemonic(KeyEvent.VK_F);

	    JMenuItem translateMenuItem = new JMenuItem("Translate");
	    JMenuItem guiMenuItem = new JMenuItem("Show Tree");

	    run.add(translateMenuItem);
	    run.add(guiMenuItem);

	    menubar.add(run);

	    frmAntlrAssemblyHelper.setJMenuBar(menubar);
		
		JLabel lblAssemblyCode = new JLabel("Assembly Code");
		lblAssemblyCode.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblAssemblyCode.setBounds(10, 11, 174, 14);
		frmAntlrAssemblyHelper.getContentPane().add(lblAssemblyCode);
		
		JLabel lbRegisterValues = new JLabel("Register Values");
		lbRegisterValues.setFont(new Font("Tahoma", Font.BOLD, 16));
		lbRegisterValues.setBounds(369, 343, 147, 14);
		frmAntlrAssemblyHelper.getContentPane().add(lbRegisterValues);
		
		JLabel lblTranslatedOutput = new JLabel("Translated Output");
		lblTranslatedOutput.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblTranslatedOutput.setBounds(369, 11, 247, 14);
		frmAntlrAssemblyHelper.getContentPane().add(lblTranslatedOutput);

		
		JScrollPane inputScrollPane = new JScrollPane();
		inputScrollPane.setBounds(10, 36, 343, 462);
		frmAntlrAssemblyHelper.getContentPane().add(inputScrollPane);
		
		JEditorPane inputEditorPane = new JEditorPane();
		inputScrollPane.setViewportView(inputEditorPane);
		
		JButton btnTranslate = new JButton("Translate");
		btnTranslate.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnTranslate.setBounds(10, 513, 343, 29);
		frmAntlrAssemblyHelper.getContentPane().add(btnTranslate);
		btnTranslate.addActionListener(
				new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
			            try {
							FileWriter out = new FileWriter(g4InputFileName);
				            out.write(inputEditorPane.getText());
							out.close();
						} catch (IOException e2) {
							// TODO Auto-generated catch block
							e2.printStackTrace();
						}
						try {
							//make call to assembly tree which runs the antlr file
							AssemblyTree tr = new AssemblyTree();
							StringHandler strHandler = tr.parse(g4InputFileName,g4FileName,"start");
							UpdateStatementTable(strHandler.StatementsOutput());
							UpdateRegisterTable(strHandler.RegistersOutput());
						} catch (IOException e1) {
							e1.printStackTrace();
						}
					}
				});
		
		JScrollPane OutputScrollPane = new JScrollPane();
		OutputScrollPane.setBounds(366, 36, 353, 299);
		frmAntlrAssemblyHelper.getContentPane().add(OutputScrollPane);
		
		//translated output jtable
		outputTable = new JTable();
		OutputScrollPane.setViewportView(outputTable);
		outputTable.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		outputTable.setModel(new DefaultTableModel(
			new Object[][] {},
			new String[] {"Instruction", "Translated Output"}
		));
		Statementmodel = (DefaultTableModel) outputTable.getModel();
		
		JScrollPane RegisterScrollPane = new JScrollPane();
		RegisterScrollPane.setBounds(369, 368, 350, 174);
		frmAntlrAssemblyHelper.getContentPane().add(RegisterScrollPane);
		
		//register jtable
		registerTable = new JTable();
		RegisterScrollPane.setViewportView(registerTable);		
		registerTable.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		registerTable.setModel(new DefaultTableModel(
			new Object[][] {},
			new String[] {"Register", "Value"}
		));
		Registermodel = (DefaultTableModel) registerTable.getModel();

	}
	
	
	/**
	 * Remove clear the table, then update the rows with the data passed in
	 * @param list	object array of strings formatted {"instruction", "translated output"}
	 */
	public void UpdateStatementTable(ArrayList<Object []> list){
		Statementmodel.setRowCount(0);
		for(Object[] statement : list){
			Statementmodel.addRow(statement);
		}
	}
	
	/**
	 * Remove clear the table, then update the rows with the data passed in
	 * @param list	object array of strings formatted {"registername", "register value"}
	 */
	public void UpdateRegisterTable(ArrayList<Object []> list){
		Registermodel.setRowCount(0);
		for(Object[] register : list){
			Registermodel.addRow(register);
		}
	}
}
