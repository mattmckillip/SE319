package assembly;
public class Register {
	public String name;
	public int value;
	public Register(String name, int value){
		this.name = name;
		this.value = value;
	}
}
