function book(title, author) {
    this.title = title;
    this.author = author;
    this.details = title + " by " + author;
}

function shelf(book, capacity, name) {
    this.books = [book];
    this.capacity = capacity;
    this.name = name;
}

function library() {
    this.shelves = [];
}

var lib = new library();



//updates the table
function update() {
    var Table = document.getElementById("libTable");
    Table.innerHTML = "";
    var i = 0;
    var j = 0;
    for (i = 0; i < 11; i++) {
        x = Table.insertRow();
        for (j = 0; j < lib.shelves.length; j++) {
            var y = x.insertCell(j);
            if (i == 0) {
                y.innerHTML = lib.shelves[j].name;
            } else {
                if (i - 1 > lib.shelves[j].books.length - 1) {
                    //what does this line do? blank line instead of a line
                    // that has the width of =========
                    y.innerHTML = "&nbsp;";
                } else {
                    y.innerHTML = " " + lib.shelves[j].books[i - 1].title;
                    y.setAttribute('data-book', lib.shelves[j].books[i - 1].details);
                    //right here?
                }
            }
        }
    }
}

function ShowShelves() {
    var Table = document.getElementById("shelfTable");
    Table.innerHTML = "";
    var i = 0;
    for (i = 0; i < lib.shelves.length; i++) {
        x = Table.insertRow();
        var y = x.insertCell();
        y.innerHTML = lib.shelves[i].name;
    }
}

function RemoveBook() {
    var title = document.getElementById("title").value;
    var author = document.getElementById("author").value;
    var i = 0;
    var j = 0;
    var flag = 0;
    for (i = 0; i < lib.shelves.length; i++) {
        if (flag==1) break;
        for (j = 0; j < lib.shelves[i].books.length; j++) {            
            if (title == (lib.shelves[i].books[j].title)) {
                lib.shelves[i].books.splice(j, 1);
                if(lib.shelves[i].books.length == 0){
                    lib.shelves.splice(i,1);
                }
                flag = 1;
                break;
            }            
        }
    }
    update();
}

//working
function isAvailable() {
    var title = document.getElementById("title").value;
    var author = document.getElementById("author").value;
    var i = 0;
    for (i = 0; i < lib.shelves.length; i++) {
        for (j = 0; j < lib.shelves[i].books.length; j++) {
            if ((lib.shelves[i].books[j].title == title) && (lib.shelves[i].books[j].author == author)) {
                alert("It's available");
                return;
            }
        }
    }
    alert("Not available");
}


function AddBook() {
    var x = document.getElementById("title").value;
    var y = document.getElementById("author").value;
    var z = document.getElementById("quantity").value;
    var i = 0;
    var letters = '/^[a-zA-Z]+$/';
    if ((parseInt(x) != (x)) && (y == parseInt(y))) {
        alert("Wrong Value Entered");
    } else {
        for (i = 0; i < z; i++) {
            var bk = new book(x, y);
            if (lib.shelves.length == 0) {
                lib.shelves.push(new shelf(bk, 10, "Shelf1"));
            } else {
                if (lib.shelves[lib.shelves.length - 1].books.length >= lib.shelves[lib.shelves.length - 1].capacity) {
                    lib.shelves.push(new shelf(bk, 10, "Shelf" + (lib.shelves.length + 1)));
                } else {
                    lib.shelves[lib.shelves.length - 1].books.push(bk);
                }
            }
        }
        update();
    }
}
